// Stub for auth.schema.js

module.exports = {};
