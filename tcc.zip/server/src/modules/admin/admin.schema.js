// Stub for admin.schema.js

module.exports = {};
