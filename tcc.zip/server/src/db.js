import dotenv from "dotenv";
import db from "./config/knexConfig.js";

dotenv.config();

export default db;
